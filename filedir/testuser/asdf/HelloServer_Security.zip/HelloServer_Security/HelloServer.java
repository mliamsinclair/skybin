import java.rmi.* ;
public class HelloServer {
       public static void main(String [] args) throws Exception {
	
              // Create and install a security manager 

	      if (System.getSecurityManager() == null) { 
	   		System.setSecurityManager(new RMISecurityManager()); 
    	      } 

              MessageWriter server = new MessageWriterImpl() ;
              Naming.rebind("messageservice", server) ;
       }
}
